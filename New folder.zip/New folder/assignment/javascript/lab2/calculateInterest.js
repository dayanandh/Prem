function compoundInterest()
{
	var principal,roi,time,compInt
	principal = 1000
	roi = 10
	time = 1
	compInt = principal * Math.pow((1+(roi/100)),time) - principal
	document.write("Principal &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp- " + principal + "<br>")
	document.write("Rate of Interest &nbsp&nbsp&nbsp- " + roi + "<br>")
	document.write("Period &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp- " + time + "<br>")
	document.write("Comp Interest &nbsp&nbsp&nbsp&nbsp&nbsp- " + compInt)
}