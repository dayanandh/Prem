var name;
var sal;
var hra;
var da;
var deduct;
var gross;
var status_submit = 0;
var tax;
var lock_fname = 0;
var lock_lname = 0;
var window_successful;

function init_onload()
{
	
}

function dyn_calc()
{	

	sal = parseInt(document.emp_dtls_form.salary.value);
	hra = parseInt(document.emp_dtls_form.hra.value);
	da = parseInt(document.emp_dtls_form.da.value);
	deduct = parseInt(document.emp_dtls_form.deduct.value);
	gross = sal + hra + da - deduct;
	
	if(!(document.emp_dtls_form.salary.value == "" || document.emp_dtls_form.hra.value == "" ||document.emp_dtls_form.da.value == "" ||document.emp_dtls_form.deduct.value == "" || document.emp_dtls_form.f_name.value == "" || document.emp_dtls_form.l_name.value == "" || document.emp_dtls_form.title.value == "Select" ))
	{
		if (gross < 0)
		{
			alert("Enter Correct value for Salary");
			status_submit = 0;
		}
		else
		{
			 							// tax is 15 %
			document.emp_dtls_form.gross.value = gross;
			name = document.emp_dtls_form.f_name.value + " " + document.emp_dtls_form.l_name.value ;
			tax = gross * 15;
			status_submit = 1;
		}
	}
	
			
}

function chk_fname()
{
	if(document.emp_dtls_form.f_name.value == "" && (!lock_fname))
	{
		//alert("First name can not be blank");
		document.getElementById("submit_handle").click();
		lock_fname = 1;
		lock_lname = 0;
		status_submit = 0;
	}	
}

function chk_lname()
{
	if(document.emp_dtls_form.l_name.value == "" && (!lock_lname))
	{
		//alert("Last name can not be blank");
		document.getElementById("submit_handle").click();
		lock_fname = 0;
		lock_lname = 1;
		status_submit = 0;
	}	
}

function submit_form()
{
	if (status_submit)	
		window_successful = window.open("page2.html","_self");
	else
	{
		alert("Fill the form properly");
		//document.getElementById("submit_handle").click();
	}
	
}


function chk_submit()
{
	window.alert("Submit value: " + status_submit);
}

