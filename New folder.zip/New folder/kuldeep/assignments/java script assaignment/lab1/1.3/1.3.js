function hello(){
	document.write("hello world this output is shown by external functions");
}