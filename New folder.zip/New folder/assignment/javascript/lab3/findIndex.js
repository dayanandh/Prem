
function findPosition(string,substring)
{
	document.write(string.indexOf(substring))
}