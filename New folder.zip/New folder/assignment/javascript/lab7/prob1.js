var barbie, caculator, mobile, dvd, total;
function calculatePrice()
{
     barbie =  parseInt(document.getElementById("txtDoll").value?document.getElementById("txtDoll").value:0)
     caculator =  parseInt(document.getElementById("txtCalcu").value?document.getElementById("txtCalcu").value:0)
     mobile =  parseInt(document.getElementById("txtMobile").value?document.getElementById("txtMobile").value:0)
     dvd = parseInt( document.getElementById("txtDVD").value?document.getElementById("txtDVD").value:0)
     total = 0
    total = barbie * 20 + caculator * 30 + mobile * 40 + dvd * 50
    if (barbie==0 && caculator==0 && mobile==0 && dvd==0) 
        alert("No item selected")
    else
    alert("Total : "+total)

}