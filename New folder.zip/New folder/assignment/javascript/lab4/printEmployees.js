
var emp = ["Tove", "Hege", "Stale", "Kai Jim", "Borge"];

function arrayOfEmployee()
{
	for(var i=1;i<=6;i++)
	{
		document.write("<b>"+i+". "+emp[i]+"</b><br>")
	}
}
