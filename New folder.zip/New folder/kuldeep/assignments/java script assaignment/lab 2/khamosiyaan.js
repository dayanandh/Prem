var i ,j ,count=1;

function loop()
{
	for(var i =1;i<=10;i++)
	{	for( var j=0;j<10;j++) 
			document.write(" " +((j*10)+i));
		    document.write("<br>");
		
	}
	
}

