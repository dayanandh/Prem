var fname, lname, title, address, basicSal, hra, pf, bonus, deduction, grossSal;
function validateForm()
{
    var expr = new RegExp("^[a-zA-Z\s]+");
    fname= document.forms["frmlab"]["fname"].value
    lname = document.getElementById("lname").value
    address = document.getElementById("address").value
    basicSal =  parseInt(document.getElementById("baseSal").value)
    hra =  parseInt(document.getElementById("hra").value)
    pf =  parseInt(document.getElementById("pf").value)
    bonus = parseInt( document.getElementById("bonus").value)
    deduction =  parseInt(document.getElementById("deduction").value)
    title = document.getElementById("empTitle").value
    grossSal = basicSal + hra + bonus + pf - deduction 
    document.getElementById("gross").value=grossSal
    if(title == 'selectTitle')
        alert("Please select a title")
    else if(fname.match(expr)!=fname)
        alert("First should be only characters with out space")
    else if(grossSal<0)
        alert("Gross sal cannot be negetive Please give correct Information")
    else if(confirm("Confirm to submit the form \nName : "+title+" "+fname+" "+lname+"\nAddress : "+address+"\nGross Salary : "+grossSal))
            window.open("success.html", "_self", "toolbar=yes,scrollbars=yes,resizable=yes");
        
}

function calGrossSal()
{
    var  basicSal, hra, pf, bonus, deduction, grossSal;
    basicSal =  parseInt(document.getElementById("baseSal").value?document.getElementById("baseSal").value:0)
    hra =  parseInt(document.getElementById("hra").value?document.getElementById("hra").value:0)
    pf =  parseInt(document.getElementById("pf").value?document.getElementById("pf").value:0)
    bonus = parseInt( document.getElementById("bonus").value?document.getElementById("bonus").value:0)
    deduction =  parseInt(document.getElementById("deduction").value?document.getElementById("deduction").value:0)
    grossSal = basicSal + hra + bonus + pf - deduction
    if(grossSal) 
        document.getElementById("gross").value=grossSal
}
