function Disp_Hello()
{
document.write("<b>Hello World!</b>")
}