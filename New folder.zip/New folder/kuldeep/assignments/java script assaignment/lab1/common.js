


var headVar;
var bodyVar;
function call()
{document.write("the actual script is in external script called as 'common.js'<br>");
	var sum=headVar+bodyVar;
document.write("the sum of two variables is :"+sum);
}