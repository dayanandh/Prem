var i ,j ,count=1;

function loop()
{
	for(var i =1;i=10;i++)
	{
		for(j=1;j=10;j++)
		{
		document.write(" " +count);
		count++;
		document.write("<br>");
		
	}
	document.write("<br>");
}
}


