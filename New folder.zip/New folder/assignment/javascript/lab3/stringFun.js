
function findMatch(str,substrng)
{
	document.write(str.match(substrng))
}

function findSubstr(str)
{
	document.write(str.substr(3,6))
}