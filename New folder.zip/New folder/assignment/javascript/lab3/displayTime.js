
function displayTime()
{
	var dateinfo, hrs, min, sec, msg , weekday , yrs, days, mon, formatedDate
	dateinfo = new Date()
	hrs = dateinfo.getHours()
	min = dateinfo.getMinutes()
	sec = dateinfo.getSeconds()
	yrs = dateinfo.getYear()+1900
	days = dateinfo.getDate()
	mon = dateinfo.toLocaleDateString("en-US", {month : 'short'})
	weekday = dateinfo.toLocaleDateString("en-US", {weekday : 'short'})
	formatedDate = weekday +" "+ mon +" "+days+" "+hrs+":"+min+":"+sec+" "+yrs 
	msg = hrs<12?"Good Morning":hrs>=12&&hrs<=17?"Good Afternoon":"Good Evening"
	document.write(formatedDate + "<br>")
	document.write(msg)
}