function sum()
{
var bsal=parseInt(document.emp.basicsal.value);
var hra=parseInt(document.emp.hra.value);
var da=parseInt(document.emp.da.value);
var bonus=parseInt(document.emp.bonus.value);
var pf=parseInt(document.emp.pf.value);
var deduc=parseInt(document.emp.deduc.value);

var tsal=bsal+hra+da+bonus+pf-deduc;

document.emp.grosssal.value=tsal;
}

